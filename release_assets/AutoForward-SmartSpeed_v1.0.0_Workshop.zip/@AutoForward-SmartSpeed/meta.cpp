name    = "Auto-Forward Smart Speed";
author  = "John2022FR";
version = "1.0";
